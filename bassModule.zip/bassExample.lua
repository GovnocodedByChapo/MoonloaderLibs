script_name("bass library test")

function main()
    if not isSampLoaded() then return end

    while not isSampAvailable() do
        wait(0)
    end

   local bass = require "lib.bass" -- загружаем модуль

    local radio = bass.BASS_StreamCreateURL("http://air.radiorecord.ru:8102/trap_320", 0, 0, nil, nil)
    bass.BASS_ChannelSetAttribute(radio, BASS_ATTRIB_VOL, 0.1)
    bass.BASS_ChannelPlay(radio, false)

    wait(-1)
end